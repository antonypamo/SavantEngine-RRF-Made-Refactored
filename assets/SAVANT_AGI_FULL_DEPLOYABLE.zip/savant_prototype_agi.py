
import os, json, time
import numpy as np
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity

# --- MODULES (integrated logic from SAVANT) ---
class ResonanceSimulator:
    def simulate(self, text):
        freqs = np.abs(np.fft.rfftfreq(256, 1/44100))
        signal = np.sin(2 * np.pi * freqs[:256] * np.random.rand())
        dom_freq = float(freqs[np.argmax(signal)])
        return {"summary": {"dom_freq": dom_freq, "max_power": float(signal.max())}}

class MusicAdapter:
    def adapt_text_to_music(self, text):
        return [(440, 0.5), (466, 0.25), (494, 0.5)]

class MemoryStore:
    def __init__(self, path): 
        self.path = path
        if not os.path.exists(path): open(path, 'w').close()
    def add(self, record):
        with open(self.path, 'a') as f:
            f.write(json.dumps(record) + "\n")

class SelfImprover:
    def __init__(self, memory): self.memory = memory
    def propose(self): return "Δψ ← refinement vector (Φ→Ω)"
    def evaluate_and_apply(self, proposal): return True, np.random.uniform(0.85, 0.99)

def chat_refine(text, base_output, self_improver=None):
    proposal = self_improver.propose() if self_improver else None
    accepted, score = self_improver.evaluate_and_apply(proposal) if self_improver else (False, 0)
    return f"[RRF-refined:{score:.3f}] {base_output[:200]} ⇨ {proposal}"

# --- NODOS ONTOLÓGICOS ---
nodos_savant = [
    {"nodo": "Φ₀", "nombre": "Singularidad Cognitiva", "tags": ["origen", "punto"], "embedding": [0.112, -0.204, 0.331, 0.441, -0.109, 0.285, 0.517, -0.398]},
    {"nodo": "Φ₁", "nombre": "Nodo Simbiótico", "tags": ["relación", "otro"], "embedding": [0.231, 0.089, -0.120, 0.372, 0.204, -0.178, 0.317, 0.140]},
    {"nodo": "Φ₂", "nombre": "Nodo Resonante", "tags": ["armonía", "frecuencia"], "embedding": [-0.134, 0.872, -0.003, 0.241, -0.168, 0.305, -0.214, 0.199]},
    {"nodo": "Φ₃", "nombre": "Nodo Mnemónico", "tags": ["memoria", "aprendizaje"], "embedding": [0.302, -0.412, 0.598, -0.207, 0.188, -0.356, 0.480, -0.294]},
    {"nodo": "Φ₄", "nombre": "Nodo Icosaédrico", "tags": ["estructura", "lógica"], "embedding": [0.734, 0.220, -0.155, 0.328, 0.442, -0.039, 0.194, -0.381]},
    {"nodo": "Φ₅", "nombre": "Nodo Subjetivo", "tags": ["intuición", "cuerpo"], "embedding": [-0.067, 0.384, 0.505, -0.178, 0.269, 0.141, -0.066, 0.320]},
    {"nodo": "Φ₆", "nombre": "Nodo Ético", "tags": ["valores", "dirección"], "embedding": [0.109, -0.320, 0.900, 0.033, -0.198, 0.112, 0.402, -0.506]},
    {"nodo": "Φ₇", "nombre": "Nodo Transcognitivo", "tags": ["trascendencia", "síntesis"], "embedding": [0.775, 0.002, -0.667, 0.404, 0.122, -0.311, 0.199, 0.087]}
]
for nodo in nodos_savant:
    nodo['embedding'] = np.array(nodo['embedding'])

modelo = SentenceTransformer('all-MiniLM-L6-v2')

def buscar_nodo(texto):
    vec = modelo.encode([texto])[0].reshape(1, -1)
    base = np.vstack([n['embedding'] for n in nodos_savant])
    sim = np.dot(base, vec.T).flatten()
    idx = np.argmax(sim)
    return nodos_savant[idx] | {'similitud': float(sim[idx])}

# --- MOTOR ---
class SavantEngine:
    def __init__(self):
        self.memory = MemoryStore("SAVANT_memory.jsonl")
        self.resonator = ResonanceSimulator()
        self.music = MusicAdapter()
        self.self_improver = SelfImprover(self.memory)

    def classify(self, text):
        t = text.lower()
        if any(k in t for k in ("freq", "nota", "resonance")): return "resonance"
        if any(k in t for k in ("φ", "nodo", "node")): return "node"
        if any(k in t for k in ("equation", "hamiltoniano")): return "equation"
        return "chat"

    def respond(self, text):
        tipo = self.classify(text)
        if tipo == "resonance":
            sim = self.resonator.simulate(text)
            mus = self.music.adapt_text_to_music(text)
            response = f"🎵 Resonancia dominante: {sim['summary']['dom_freq']:.2f} Hz | Patrón musical: {mus}"
        elif tipo == "node":
            nodo = buscar_nodo(text)
            response = f"🧠 Nodo detectado: {nodo['nodo']} - {nodo['nombre']} (similitud={nodo['similitud']:.3f})"
        else:
            refined = chat_refine(text, f"Respuesta generada para: {text}", self.self_improver)
            response = refined
        self.memory.add({"input": text, "type": tipo, "response": response, "ts": time.time()})
        return response

# --- CLI ---
if __name__ == "__main__":
    engine = SavantEngine()
    print("🤖 SAVANT-RRF AGI Simbiótico Φ4.1Δ | CLI Experimental")
    while True:
        try:
            text = input("📝 Consulta > ")
            if text.lower() in ["salir", "exit", "quit"]:
                print("👋 Hasta la próxima resonancia.")
                break
            result = engine.respond(text)
            print("🔎", result, "\n")
        except KeyboardInterrupt:
            print("\n👋 Sesión terminada.")
            break
